// =============================================================================
// README.TXT
// -----------------------------------------------------------------------------
// Information about the X Shortcodes plugin.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Information
// =============================================================================

// Information
// =============================================================================

Thank you for choosing to use X!

For the latest information on the X Shortcodes plugin, make sure to register for
access to our member area where we provide extensive documentation and all
official support: theme.co/x/go/register.php